<!-- The file that handles the submission of the form from the client. -->
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="landing.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <title>Thank you</title>
  </head>
  <h1>You have booked your room, we will contact you with the information.. </h1>
  <h2>More is coming to this page soon...</h2>
  <body>
    <?php
        $firstName = $_POST['firstName'];
        $lastName = $_POST['lastName'];
        $phonenum = $_POST['phonenum'];
        $email = $_POST['email'];
        $arrive = $_POST['arrive'];
        $leave= $_POST['leave'];
        $roomtype = $_POST['roomtype'];

        //Creating the connection.
        $conn = new mysqli('localhost','root','','java_hotel_db');

        //Checking the connection.
        if($conn->connect_error){
          die('Connection Failed: '.$conn->connect_error);
        }else{

          //Inserting the client to the clients table.
          $sql1 = "INSERT INTO clients (first_name,last_name,phone,email) VALUES (?,?,?,?)";
          $stmt1 = mysqli_prepare($conn, $sql1);
          $stmt1->bind_param("ssss",$firstName,$lastName,$phonenum,$email);
          $stmt1->execute();

          //Getting the Client's ID.
          $sql2 = 'SELECT id,first_name,last_name FROM clients WHERE phone="'.$phonenum.'"';
          $stmt2 = mysqli_query($conn,$sql2);
          $result2 = $conn->query($sql2);

          $clientID = "";

          if ($result2->num_rows > 0) {
            while($row = $result2->fetch_assoc()) {
              $clientID = $row["id"];
              //This print was used when we needed to see the client's ID during the testing stages.
              //echo $clientID. "<br>";
            }
          } else {
              echo "0 results". "<br>";
          }

          //Getting the number of the first free room.
          //It has to have the type chosen by the client and be not reserved.
          $sql3 = "SELECT r_number, type FROM rooms WHERE reserved='No'"; 
          $stmt3 = mysqli_query($conn,$sql3);
          $result3 = $conn->query($sql3);

          $roomNumber = "";

          if ($result3->num_rows > 0) {
              while($row = $result3->fetch_assoc()) {
                  if ($row["type"] == $_POST['roomtype']) {
                    $roomNumber = $row["r_number"];
                    echo "Your room number is ".$roomNumber.".". "<br>";
                    break;
                  }
              }
          } else {
              echo "0 results". "<br>";
          }

          //Inserting the reservation into the reservations table.
          $sql10 = "INSERT INTO reservations (client_id,room_number,date_in,date_out) VALUES (?,?,?,?)";
          $stmt10 = mysqli_prepare($conn, $sql10);
          $stmt10->bind_param("ssss",$clientID,$roomNumber,$arrive,$leave);
          $stmt10->execute();

          //Setting the room to be reserved - updating "no" to "yes".
          $sql5 = 'UPDATE rooms SET reserved="Yes" WHERE r_number="'.$roomNumber.'"';
          $stmt5 = mysqli_prepare($conn, $sql5);
          $stmt5->execute();

          //Calculate the price. Price = date * price for one night.
          //Calculate the date.
          $earlier = new DateTime($arrive);
          $later = new DateTime($leave);
          $diff = $later->diff($earlier)->format("%a");
          //Get the price for one night.
          $sql6 = 'SELECT price FROM type WHERE id="'.$roomtype.'"';
          $stmt6 = $conn->query($sql6);
          $result6 = $stmt6->fetch_assoc();
          $priceForOne = $result6['price'];
          //Multiply date and price.
          $price = $diff * $priceForOne;
          echo "The price of your reservation is ". $price .".". "<br>";

          //End the registration process.
          $stmt1->close();
          $stmt10->close();
          $conn->close();
        }
    ?>
</body>
</html>